/**
 * Webify Multi-Platform International Lead Scraper
 * Discovers businesses & founders worldwide (Focus: USA, UK, Canada, Australia, India)
 * Targets businesses needing a modern website OR wanting an AI Lead Bot (180+ leads/day)
 */

const fs = require('fs');
const path = require('path');

const APIFY_TOKEN = process.env.APIFY_API_TOKEN;
const LEADS_FILE = path.join(__dirname, 'leads_db.json');
const BACKUP_FILE = path.join(__dirname, 'leads_db.backup.json');
const SENT_HISTORY_FILE = path.join(__dirname, 'sent_history.json');

let cachedDb = null;

/**
 * Permanent Sent History Tracker (Ensures NO recipient is EVER messaged twice)
 */
function loadSentHistory() {
  try {
    if (fs.existsSync(SENT_HISTORY_FILE)) {
      const raw = fs.readFileSync(SENT_HISTORY_FILE, 'utf8');
      const list = JSON.parse(raw);
      if (Array.isArray(list)) return new Set(list);
    }
  } catch (e) {}
  return new Set();
}

function recordSentPhone(phone) {
  if (!phone) return;
  const digits = String(phone).replace(/\D/g, '');
  const history = loadSentHistory();
  history.add(digits);
  try {
    fs.writeFileSync(SENT_HISTORY_FILE, JSON.stringify([...history], null, 2), 'utf8');
  } catch (e) {}
}

function recordBulkSentPhones(phoneList) {
  if (!Array.isArray(phoneList)) return { added: 0, total: 0 };
  const history = loadSentHistory();
  let added = 0;
  for (const p of phoneList) {
    const digits = String(p).replace(/\D/g, '');
    if (digits && digits.length >= 7 && !history.has(digits)) {
      history.add(digits);
      added++;
    }
  }
  if (added > 0) {
    try {
      fs.writeFileSync(SENT_HISTORY_FILE, JSON.stringify([...history], null, 2), 'utf8');
      console.log(`🛡️ [Sent History Shield] Recorded ${added} past numbers in permanent shield ledger. Total shielded: ${history.size}`);
    } catch (e) {
      console.error('Error saving sent history:', e.message);
    }
  }
  return { added, total: history.size };
}

function getTotalShieldedCount() {
  return loadSentHistory().size;
}

function isPhoneAlreadySent(phone) {
  if (!phone) return false;
  const digits = String(phone).replace(/\D/g, '');
  const history = loadSentHistory();
  return history.has(digits);
}

function loadDatabase() {
  if (cachedDb && cachedDb.leads && Array.isArray(cachedDb.leads)) {
    return cachedDb;
  }
  try {
    if (fs.existsSync(LEADS_FILE)) {
      const raw = fs.readFileSync(LEADS_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.leads)) {
        cachedDb = parsed;
        return cachedDb;
      }
    }
  } catch (e) {
    console.warn('⚠️ Main leads_db.json read error, attempting backup restore:', e.message);
  }

  // Fallback to backup file
  try {
    if (fs.existsSync(BACKUP_FILE)) {
      const raw = fs.readFileSync(BACKUP_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.leads)) {
        console.log('✅ Successfully restored leads database from backup!');
        cachedDb = parsed;
        return cachedDb;
      }
    }
  } catch (backupErr) {
    console.error('Backup read failed:', backupErr.message);
  }

  cachedDb = { leads: [], sentCount: 0 };
  return cachedDb;
}

function saveDatabase(db) {
  if (!db || !Array.isArray(db.leads)) return;
  cachedDb = db;
  const tempFile = path.join(__dirname, `leads_db.tmp.${Date.now()}`);
  try {
    const jsonStr = JSON.stringify(db, null, 2);
    // 1. Write to temporary file first
    fs.writeFileSync(tempFile, jsonStr, 'utf8');
    // 2. Atomic rename (POSIX atomic on Linux - never corrupts or half-writes!)
    fs.renameSync(tempFile, LEADS_FILE);
    // 3. Keep mirrored backup file
    fs.writeFileSync(BACKUP_FILE, jsonStr, 'utf8');
  } catch (e) {
    console.error('Error saving leads DB:', e.message);
    if (fs.existsSync(tempFile)) {
      try { fs.unlinkSync(tempFile); } catch (err) {}
    }
  }
}

/**
 * Clean & Format International Phone Numbers into Baileys JID (E.164: <countryCode><digits>@s.whatsapp.net)
 * Full support for USA (+1), UK (+44), India (+91), Canada (+1), Australia (+61), etc.
 */
function formatWhatsAppJid(rawNumber) {
  if (!rawNumber) return null;
  let rawStr = String(rawNumber).trim();
  let digits = rawStr.replace(/\D/g, '');

  let country = 'GLOBAL';

  // 1. Explicit Country Code Matching (+91, +1, +44, +61)
  if (rawStr.startsWith('+91') || (digits.startsWith('91') && digits.length === 12)) {
    digits = digits.startsWith('91') ? digits : '91' + digits;
    country = 'India';
  } else if (rawStr.startsWith('+1') || (digits.startsWith('1') && digits.length === 11)) {
    digits = digits.startsWith('1') ? digits : '1' + digits;
    country = 'USA';
  } else if (rawStr.startsWith('+44') || (digits.startsWith('44') && (digits.length === 12 || digits.length === 11))) {
    digits = digits.startsWith('44') ? digits : '44' + digits;
    country = 'UK';
  } else if (digits.startsWith('07') && digits.length === 11) {
    digits = '44' + digits.slice(1);
    country = 'UK';
  } else if (rawStr.startsWith('+61') || (digits.startsWith('61') && digits.length === 11)) {
    digits = digits.startsWith('61') ? digits : '61' + digits;
    country = 'Australia';
  }
  // 2. Unprefixed 10-digit numbers:
  // If starts with 6, 7, 8, 9 and user didn't specify +1, can be Indian or US
  // Default to US (+1) as USA is primary target, unless explicitly formatted
  else if (digits.length === 10) {
    // Standard US 10-digit number
    digits = '1' + digits;
    country = 'USA';
  } else if (digits.startsWith('0') && digits.length === 11) {
    // 0 followed by 10-digit Indian number
    digits = '91' + digits.slice(1);
    country = 'India';
  }
  // 4. Australia (+61)
  else if (digits.startsWith('04') && digits.length === 10) {
    digits = '61' + digits.slice(1);
    country = 'Australia';
  } else if (digits.startsWith('61') && digits.length === 11) {
    country = 'Australia';
  }
  // 5. Generic international E.164 (Between 10 and 15 digits)
  else if (digits.length >= 10 && digits.length <= 15) {
    country = 'GLOBAL';
  } else {
    return null; // Invalid length or format
  }

  return {
    cleanNumber: digits,
    jid: `${digits}@s.whatsapp.net`,
    country: country
  };
}

/**
 * Add unique leads to database (prioritizing USA leads at the front of the queue)
 */
function addLeadsToQueue(newLeads = []) {
  const db = loadDatabase();
  const existingPhones = new Set(db.leads.map(l => l.phone));
  let added = 0;

  for (const item of newLeads) {
    const formatted = formatWhatsAppJid(item.phone || item.number);
    if (!formatted) continue;

    // Never queue numbers that were already messaged in past sessions
    if (isPhoneAlreadySent(formatted.cleanNumber)) {
      continue;
    }

    if (!existingPhones.has(formatted.cleanNumber)) {
      const newLeadObj = {
        phone: formatted.cleanNumber,
        jid: formatted.jid,
        country: formatted.country || item.country || 'USA',
        name: item.name || '',
        niche: item.niche || 'Business Owner',
        trade: item.trade || item.niche || 'local service',
        city: item.city || 'your area',
        source: item.source || 'apify_web',
        query: item.query || '',
        discoveredAt: new Date().toISOString(),
        status: 'queued', // queued, sent, replied, failed
        lastSentAt: null
      };

      // Prioritize USA leads by pushing them to the top of queued items
      if (formatted.country === 'USA') {
        const firstNonUsaIdx = db.leads.findIndex(l => l.status === 'queued' && l.country !== 'USA');
        if (firstNonUsaIdx !== -1) {
          db.leads.splice(firstNonUsaIdx, 0, newLeadObj);
        } else {
          db.leads.push(newLeadObj);
        }
      } else {
        db.leads.push(newLeadObj);
      }

      existingPhones.add(formatted.cleanNumber);
      added++;
    }
  }

  saveDatabase(db);
  console.log(`✅ [Webify Leads DB] Added ${added} new unique leads. Total in DB: ${db.leads.length}`);
  return { added, total: db.leads.length };
}

/**
 * Get next batch of queued leads
 */
function getQueuedLeads(limit = 10) {
  const db = loadDatabase();
  return db.leads.filter(l => l.status === 'queued').slice(0, limit);
}

/**
 * Update status of a lead
 */
function updateLeadStatus(phone, status, error = null) {
  const db = loadDatabase();
  const cleanDigits = String(phone).replace(/\D/g, '');
  const lead = db.leads.find(l => l.phone === cleanDigits || l.phone === phone || l.jid.includes(cleanDigits));
  if (lead) {
    lead.status = status;
    if (status === 'sent') {
      lead.lastSentAt = new Date().toISOString();
      db.sentCount = (db.sentCount || 0) + 1;
      recordSentPhone(cleanDigits);
    }
    if (error) lead.lastError = error;
    saveDatabase(db);
  }
}

/**
 * Trigger Apify Search to extract businesses needing websites OR lead bots (<30 days old)
 * Priority focus: USA businesses, plus global markets (UK, Canada, India)
 */
async function triggerApifyLeadDiscovery() {
  if (!APIFY_TOKEN) {
    console.warn('⚠️ APIFY_API_TOKEN is missing in .env');
    return [];
  }

  console.log('🔍 [Apify Webify] Running lead discovery for businesses needing websites or 180+ leads/day...');
  
  // High-converting search queries across platforms targeting businesses without websites or looking for growth
  const searchQueries = [
    // 1. US Local Businesses on social media advertising without website link
    'site:facebook.com ("call or text to book" OR "DM to order") ("cleaner" OR "contractor" OR "landscaping" OR "roofer" OR "gym" OR "medspa") -site:linktr.ee',
    'site:instagram.com ("call or text" OR "DM for inquiries") ("no website" OR "website coming soon") -site:linktr.ee',
    
    // 2. Small Business & Entrepreneur Communities (US/Global)
    'site:reddit.com/r/smallbusiness ("need a website for my business" OR "looking for web designer" OR "need more leads")',
    'site:reddit.com/r/Entrepreneur ("how to get 100 leads" OR "need a landing page built")',
    
    // 3. Businesses openly requesting websites or lead generation services
    'site:twitter.com ("need a website for my" OR "looking to hire web developer" OR "need lead gen agency")',
    'site:quora.com ("best website development agency for small business" OR "how can a business get 150 leads a day")',

    // 4. US Service Providers advertising phone numbers on directory pages
    '("contractor" OR "hvac" OR "plumber" OR "realtor" OR "coach") ("call or text" OR "text us at") ("+1" OR "phone:") -site:yelp.com',
    '("roofing" OR "dentist" OR "chiropractor") ("website under construction" OR "new business") ("phone" OR "contact")'
  ];

  try {
    const runResponse = await fetch(`https://api.apify.com/v2/acts/apify~google-search-scraper/run-sync-get-dataset-items?token=${APIFY_TOKEN}&memory=512`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        queries: searchQueries.join('\n'),
        maxPagesPerQuery: 1,
        resultsPerPage: 25,
        mobileResults: true,
        languageCode: 'en'
      })
    });

    if (!runResponse.ok) {
      console.warn(`Apify actor notice (${runResponse.status}): ${await runResponse.text()}`);
      return [];
    }

    const items = await runResponse.json();
    const extracted = [];

    // Comprehensive International Phone Regex (USA, UK, India, Global E.164)
    // Matches formats like: +1 (555) 234-5678, 555-234-5678, +44 7911 123456, +91 9876543210
    const phoneRegex = /(?:\+?1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})\b|(?:\+?44[-.\s]?|0)7\d{3}[-.\s]?\d{6}\b|(?:\+?91|0)?[6-9]\d{9}\b|\+?[1-9]\d{9,14}\b/g;

    for (const item of items) {
      const textToSearch = `${item.title || ''} ${item.description || ''} ${item.snippet || ''}`;
      const matches = textToSearch.match(phoneRegex);
      if (matches) {
        for (const phone of matches) {
          extracted.push({
            phone: phone,
            name: (item.title || '').split(/[-|–]/)[0].trim().slice(0, 30),
            niche: (item.searchQuery || 'Business Owner').slice(0, 25),
            source: 'apify_webify_scraper',
            query: item.searchQuery || ''
          });
        }
      }
    }

    console.log(`🎯 [Apify Webify] Discovered ${extracted.length} raw business contacts worldwide.`);
    return addLeadsToQueue(extracted);
  } catch (err) {
    console.error('❌ Apify Run Failed:', err.message);
    return [];
  }
}

/**
 * 100% Free US & Global Web Scraper (Zero API Key / Zero Cost)
 * Crawls high-intent service businesses, contractors, cleaners, remodeling & local founders
 * Prioritizes US (+1) small business owners needing websites and 180+ leads/day AI bots
 */
const TOLL_FREE_PREFIXES = new Set(['800', '888', '877', '866', '855', '844', '833']);

const TARGET_US_CITIES = [
  'houston', 'miami', 'dallas', 'phoenix', 'losangeles', 
  'chicago', 'atlanta', 'austin', 'orlando', 'tampa', 
  'lasvegas', 'denver', 'sandiego', 'charlotte', 'seattle',
  'sanantonio', 'philadelphia', 'boston', 'nashville', 'raleigh'
];

const TARGET_NICHES = [
  'contractor', 'remodeling', 'cleaning', 'roofing', 'landscaping',
  'plumber', 'painter', 'handyman', 'electrician', 'moving', 
  'hvac', 'pressure washing', 'flooring', 'pest control', 'appliance repair'
];

function isTollFree(cleanNumber) {
  const digits = String(cleanNumber).replace(/\D/g, '');
  const areaCode = digits.startsWith('1') ? digits.slice(1, 4) : digits.slice(0, 3);
  return TOLL_FREE_PREFIXES.has(areaCode);
}

let is247ScraperRunning = false;
let isScraperPaused = false;
let scraperStats = {
  status: 'Starting 24/7 autonomous harvest...',
  cyclesCompleted: 0,
  leadsHarvestedSession: 0,
  lastScrapedCity: 'Dallas',
  lastScrapedNiche: 'plumber',
  lastRunTime: null
};

function pauseScraper() {
  isScraperPaused = true;
  scraperStats.status = 'Scraper Stopped / Paused by User';
  console.log('⏸️ [Free Scraper Engine] Paused by user.');
}

function resumeScraper() {
  isScraperPaused = false;
  scraperStats.status = 'Resuming autonomous harvest...';
  console.log('▶️ [Free Scraper Engine] Resumed by user.');
}

function getScraperStats() {
  const db = loadDatabase();
  return {
    ...scraperStats,
    isPaused: isScraperPaused,
    totalInDb: db.leads.length,
    queuedCount: db.leads.filter(l => l.status === 'queued').length,
    sentCount: db.leads.filter(l => l.status === 'sent').length
  };
}

async function start247ContinuousScraper() {
  if (is247ScraperRunning) return;
  is247ScraperRunning = true;
  console.log('🌍 [24/7 Web Scraper Engine] Started non-stop autonomous lead harvest loop!');

  while (is247ScraperRunning) {
    if (isScraperPaused) {
      scraperStats.status = 'Scraper Stopped / Paused by User';
      await new Promise(resolve => setTimeout(resolve, 3000));
      continue;
    }

    try {
      const db = loadDatabase();
      const queuedCount = db.leads.filter(l => l.status === 'queued').length;

      // If backlog is healthy (>= 60 leads queued), rest 2 minutes to keep CPU minimal
      if (queuedCount >= 60) {
        scraperStats.status = `Queue healthy (${queuedCount} leads queued). Resting 2 mins before next sweep...`;
        await new Promise(resolve => setTimeout(resolve, 2 * 60 * 1000));
        continue;
      }

      // Pick next city and niche
      const city = TARGET_US_CITIES[Math.floor(Math.random() * TARGET_US_CITIES.length)];
      const niche = TARGET_NICHES[Math.floor(Math.random() * TARGET_NICHES.length)];

      scraperStats.lastScrapedCity = city;
      scraperStats.lastScrapedNiche = niche;
      scraperStats.lastRunTime = new Date().toISOString();
      scraperStats.status = `Turbo harvesting in ${city.toUpperCase()} (${niche})...`;

      const result = await triggerFreeWebScraper({
        targetCount: 30,
        targetCity: city,
        targetNiche: niche
      });

      scraperStats.cyclesCompleted++;
      scraperStats.leadsHarvestedSession += (result?.added || 0);
      scraperStats.status = `Active (Last sweep added ${result?.added || 0} leads).`;

      // Fast pacing: if queue is under 30 leads, sweep again in 3s; otherwise polite 15s pause
      if (queuedCount < 30) {
        await new Promise(resolve => setTimeout(resolve, 3000));
      } else {
        await new Promise(resolve => setTimeout(resolve, 15000));
      }
    } catch (err) {
      console.error('❌ [24/7 Scraper Exception]', err.message);
      scraperStats.status = `Resuming after glitch (${err.message})...`;
      await new Promise(resolve => setTimeout(resolve, 15000));
    }
  }
}

async function triggerFreeWebScraper(options = {}) {
  const minLeads = options.targetCount || 30;
  console.log(`⚡ [Turbo Free Scraper] Starting high-velocity harvest (Target: ${minLeads}+ verified US leads)...`);

  const extracted = [];
  const seenPhonesInBatch = new Set();
  const phoneRegex = /(?:\+?1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})\b/g;

  // Use specified city/niche or full shuffle
  const cityList = options.targetCity ? [options.targetCity] : [...TARGET_US_CITIES].sort(() => 0.5 - Math.random());
  const nicheList = options.targetNiche ? [options.targetNiche] : [...TARGET_NICHES].sort(() => 0.5 - Math.random());

  for (const city of cityList) {
    if (extracted.length >= minLeads) break;

    for (const niche of nicheList) {
      if (extracted.length >= minLeads) break;

      const searchUrl = `https://${city}.craigslist.org/search/bbb?query=${encodeURIComponent(niche)}`;
      
      try {
        const res = await fetch(searchUrl, {
          signal: AbortSignal.timeout(6000),
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
          }
        });

        if (!res.ok) continue;
        const html = await res.text();
        const results = [...html.matchAll(/<li class="cl-static-search-result"[^>]*>(.*?)<\/li>/gs)].map(m => m[1]);
        if (results.length === 0) continue;

        const candidatePostsToFetch = [];

        // 1. FAST-PATH: Instant extraction from search cards (0ms overhead)
        for (const r of results) {
          if (extracted.length >= minLeads) break;

          const titleMatch = r.match(/<div class="title">(.*?)<\/div>/);
          const rawTitle = titleMatch ? titleMatch[1].replace(/<[^>]+>/g, '').trim() : `${niche} specialist`;
          const matches = [...r.matchAll(phoneRegex)].map(m => m[0]);

          let foundInCard = false;
          for (const phone of matches) {
            const cleanDigits = phone.replace(/\D/g, '');
            if ((cleanDigits.length === 10 || (cleanDigits.length === 11 && cleanDigits.startsWith('1'))) && !isTollFree(cleanDigits)) {
              if (!seenPhonesInBatch.has(cleanDigits) && !isPhoneAlreadySent(cleanDigits)) {
                seenPhonesInBatch.add(cleanDigits);
                extracted.push({
                  phone: phone,
                  name: rawTitle.replace(/[^\w\s-]/g, '').slice(0, 35).trim() || 'Business Owner',
                  niche: `${niche.charAt(0).toUpperCase() + niche.slice(1)} (${city})`,
                  trade: niche,
                  city: city,
                  country: 'USA',
                  source: 'free_turbo_scraper',
                  query: `${city} - ${niche}`
                });
                foundInCard = true;
                break;
              }
            }
          }

          // If phone not in title/snippet, queue post URL for fast parallel fetch
          if (!foundInCard && candidatePostsToFetch.length < 10) {
            const linkMatch = r.match(/<a href="([^"]+)"/);
            if (linkMatch) {
              candidatePostsToFetch.push({ postUrl: linkMatch[1], rawTitle });
            }
          }
        }

        // 2. PARALLEL FETCH for remaining post bodies (Concurrent batches)
        if (extracted.length < minLeads && candidatePostsToFetch.length > 0) {
          const fetchPromises = candidatePostsToFetch.map(async ({ postUrl, rawTitle }) => {
            try {
              const postRes = await fetch(postUrl, {
                signal: AbortSignal.timeout(5000),
                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36' }
              });
              if (!postRes.ok) return null;
              const postHtml = await postRes.text();
              const bodyMatch = postHtml.match(/<section id="postingbody"[^>]*>(.*?)<\/section>/s);
              if (!bodyMatch) return null;
              const bodyClean = bodyMatch[1].replace(/<[^>]+>/g, ' ');
              const foundPhones = [...bodyClean.matchAll(phoneRegex)].map(m => m[0]);
              for (const phone of foundPhones) {
                const cleanDigits = phone.replace(/\D/g, '');
                if ((cleanDigits.length === 10 || (cleanDigits.length === 11 && cleanDigits.startsWith('1'))) && !isTollFree(cleanDigits)) {
                  return { phone, rawTitle, cleanDigits };
                }
              }
            } catch (e) {
              return null;
            }
            return null;
          });

          const postResults = await Promise.allSettled(fetchPromises);
          for (const pr of postResults) {
            if (pr.status === 'fulfilled' && pr.value) {
              const { phone, rawTitle, cleanDigits } = pr.value;
              if (!seenPhonesInBatch.has(cleanDigits) && !isPhoneAlreadySent(cleanDigits)) {
                seenPhonesInBatch.add(cleanDigits);
                extracted.push({
                  phone: phone,
                  name: rawTitle.replace(/[^\w\s-]/g, '').slice(0, 35).trim() || 'Business Owner',
                  niche: `${niche.charAt(0).toUpperCase() + niche.slice(1)} (${city})`,
                  trade: niche,
                  city: city,
                  country: 'USA',
                  source: 'free_turbo_scraper',
                  query: `${city} - ${niche}`
                });
              }
            }
          }
        }
      } catch (searchErr) {
        // Skip on network notice
      }
    }
  }

  console.log(`🎯 [Turbo Free Scraper] Extracted ${extracted.length} verified US business leads (0% API cost).`);
  return addLeadsToQueue(extracted);
}

module.exports = {
  loadDatabase,
  saveDatabase,
  addLeadsToQueue,
  getQueuedLeads,
  updateLeadStatus,
  triggerFreeWebScraper,
  triggerApifyLeadDiscovery,
  start247ContinuousScraper,
  pauseScraper,
  resumeScraper,
  isPhoneAlreadySent,
  recordSentPhone,
  recordBulkSentPhones,
  getTotalShieldedCount,
  getScraperStats,
  formatWhatsAppJid
};
