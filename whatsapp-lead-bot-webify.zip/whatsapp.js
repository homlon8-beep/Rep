/**
 * Baileys WhatsApp Multi-Device Client
 * Manages WebSocket connection, live QR generation, auto-reconnect, and AI reply handler
 */

const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const pino = require('pino');
const QRCode = require('qrcode');
const path = require('path');
const ai = require('./ai');
const scraper = require('./scraper');

const AUTH_DIR = path.join(__dirname, 'auth_info_baileys');

let sock = null;
let currentQrCodeDataUrl = null;
let isConnectedState = false;
let userPhone = null;

// Store in-memory conversation history for contextual AI replies (bounded to prevent memory leaks)
const conversationHistories = new Map();

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Pending inbound message queue for slow real-human replies (debounces bursts & mimics human typing)
const pendingReplies = new Map();

// Shield Set for all past chats synced directly from WhatsApp (Older bot contacts & personal chats)
const existingChatsSet = new Set();

function registerExistingChat(jid) {
  if (!jid) return;
  const cleanDigits = String(jid).split('@')[0].replace(/\D/g, '');
  if (cleanDigits && cleanDigits.length >= 7) {
    existingChatsSet.add(cleanDigits);
    scraper.recordSentPhone(cleanDigits);
  }
}

function hasExistingChat(phoneOrJid) {
  if (!phoneOrJid) return false;
  const cleanDigits = String(phoneOrJid).replace(/\D/g, '');
  return existingChatsSet.has(cleanDigits) || scraper.isPhoneAlreadySent(cleanDigits);
}

let isReconnecting = false;

// Helper to extract text from all nested WhatsApp message types (ephemeral, viewOnce, button replies, etc.)
function extractMessageText(msg) {
  if (!msg || !msg.message) return '';
  let m = msg.message;

  // Unwrap ephemeral (disappearing messages), view-once, and document wrappers
  if (m.ephemeralMessage?.message) m = m.ephemeralMessage.message;
  if (m.viewOnceMessage?.message) m = m.viewOnceMessage.message;
  if (m.viewOnceMessageV2?.message) m = m.viewOnceMessageV2.message;
  if (m.documentWithCaptionMessage?.message) m = m.documentWithCaptionMessage.message;

  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.buttonsResponseMessage?.selectedDisplayText ||
    m.buttonsResponseMessage?.selectedButtonId ||
    m.templateButtonReplyMessage?.selectedId ||
    m.templateButtonReplyMessage?.selectedDisplayText ||
    m.listResponseMessage?.title ||
    m.listResponseMessage?.singleSelectReply?.selectedRowId ||
    ''
  );
}

async function initWhatsApp(onReadyCallback) {
  // Prevent socket accumulation by properly closing previous instance
  if (sock) {
    try {
      sock.ev.removeAllListeners();
      sock.end();
    } catch (e) {}
    sock = null;
  }

  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);

  sock = makeWASocket({
    auth: state,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    browser: ['Webify Cloud Bot', 'Chrome', '124.0.0']
  });

  // Save auth state changes
  sock.ev.on('creds.update', saveCreds);

  // Connection update event
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      try {
        currentQrCodeDataUrl = await QRCode.toDataURL(qr);
        console.log('📲 [WhatsApp QR] New QR Code generated! Open /qr in browser to scan.');
      } catch (err) {
        console.error('Failed to generate QR data URL:', err.message);
      }
    }

    if (connection === 'close') {
      isConnectedState = false;
      currentQrCodeDataUrl = null;
      const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log(`⚠️ [WhatsApp] Socket closed (${lastDisconnect?.error?.message || 'timeout'}). Reconnecting: ${shouldReconnect}`);
      
      if (shouldReconnect && !isReconnecting) {
        isReconnecting = true;
        setTimeout(() => {
          isReconnecting = false;
          initWhatsApp(onReadyCallback);
        }, 5000);
      } else if (!shouldReconnect) {
        console.log('❌ [WhatsApp] Session logged out. Open /qr to rescan.');
      }
    } else if (connection === 'open') {
      isConnectedState = true;
      currentQrCodeDataUrl = null;
      isReconnecting = false;
      userPhone = sock.user?.id ? sock.user.id.split(':')[0] : 'Connected';
      console.log(`\n🎉 [WhatsApp] Connected successfully as +${userPhone}! Bot is LIVE.\n`);
      if (onReadyCallback) onReadyCallback();
    }
  });

  // Chat History Synchronization: Shields all contacts messaged by older bots or personal chats
  sock.ev.on('messaging-history.set', ({ chats }) => {
    if (Array.isArray(chats)) {
      console.log(`📥 [WhatsApp History Sync] Found ${chats.length} existing chats on this phone. Shielding all from outreach...`);
      for (const c of chats) registerExistingChat(c.id);
    }
  });

  sock.ev.on('chats.set', ({ chats }) => {
    if (Array.isArray(chats)) {
      for (const c of chats) registerExistingChat(c.id);
    }
  });

  sock.ev.on('chats.upsert', (chats) => {
    if (Array.isArray(chats)) {
      for (const c of chats) registerExistingChat(c.id);
    }
  });

  // Incoming message event (Lead replies) - Handles @s.whatsapp.net AND @lid, ephemerals, and buttons
  sock.ev.on('messages.upsert', async (m) => {
    try {
      if (!m.messages || !Array.isArray(m.messages)) return;

      for (const msg of m.messages) {
        if (!msg || !msg.message) continue;

        const senderJid = msg.key.remoteJid;
        if (!senderJid) continue;

        const cleanPhone = senderJid.replace(/@.*$/, '').replace(/\D/g, '');

        // If WE sent a message from our own phone (fromMe: true), cancel any pending AI reply
        // so you have full freedom to manually close deals without the bot talking over you!
        if (msg.key.fromMe) {
          if (pendingReplies.has(cleanPhone)) {
            clearTimeout(pendingReplies.get(cleanPhone).timeout);
            pendingReplies.delete(cleanPhone);
            console.log(`✋ [Manual Override] You messaged ${cleanPhone} from your phone. Canceled pending AI auto-reply.`);
          }
          continue;
        }

        // Ignore group chats, broadcast channels, and status stories
        if (senderJid.endsWith('@g.us') || senderJid.endsWith('@broadcast') || senderJid === 'status@broadcast') {
          continue;
        }

        const incomingText = extractMessageText(msg).trim();
        if (!incomingText) continue;

        console.log(`\n📩 [Inbound Lead Message from ${cleanPhone} (${senderJid})]: "${incomingText}"`);

        // Check if lead requested to STOP / opt out
        const lower = incomingText.toLowerCase();
        if (lower === 'stop' || lower === 'unsubscribe' || lower === 'remove' || lower.includes('stop')) {
          if (pendingReplies.has(cleanPhone)) {
            clearTimeout(pendingReplies.get(cleanPhone).timeout);
            pendingReplies.delete(cleanPhone);
          }
          console.log(`🛑 [Opt-Out Received from ${cleanPhone}]: Blacklisted permanently from all future outreach.`);
          try {
            scraper.updateLeadStatus(cleanPhone, 'opted_out');
            scraper.recordSentPhone(cleanPhone);
            const optOutReply = 'You have been opted out and will receive no further messages. Thank you!';
            await sock.sendMessage(senderJid, { text: optOutReply });
          } catch (e) {}
          continue;
        }

        // Update DB status to 'replied' and shield in sent history
        try {
          scraper.updateLeadStatus(cleanPhone, 'replied');
          scraper.recordSentPhone(cleanPhone);
        } catch (e) {}

        // =================================================================
        // SLOW REAL-HUMAN AI REPLY SCHEDULING (Natural Anti-Ban Simulation)
        // =================================================================
        // If user sends multiple messages rapidly, buffer them together into one thoughtful reply
        let pending = pendingReplies.get(cleanPhone);
        if (pending) {
          clearTimeout(pending.timeout);
          pending.messages.push(incomingText);
          pending.lastMsgKey = msg.key;
        } else {
          pending = {
            senderJid,
            cleanPhone,
            messages: [incomingText],
            lastMsgKey: msg.key,
            timeout: null
          };
        }

        // Natural human debounce delay: 18 to 28 seconds (waits to see if contact sends a 2nd text)
        const debounceDelayMs = 18000 + Math.floor(Math.random() * 10000);
        console.log(`⏳ [Slow Human AI] Buffered reply for ${cleanPhone}. Waiting ${(debounceDelayMs / 1000).toFixed(0)}s debounce before reading & typing...`);

        pending.timeout = setTimeout(async () => {
          pendingReplies.delete(cleanPhone);
          await processSlowHumanReply(pending);
        }, debounceDelayMs);

        pendingReplies.set(cleanPhone, pending);
      }
    } catch (msgErr) {
      console.error('❌ [Error handling incoming messages]:', msgErr.message);
    }
  });

  return sock;
}

/**
 * Process Slow Real-Human AI Reply
 * Flow:
 * 1. Mark as read (blue ticks)
 * 2. Slow human reading & thinking pause (12s to 24s)
 * 3. Generate contextual AI reply via Groq
 * 4. Human typing presence ('composing') based on message length (7s to 18s)
 * 5. Pre-send hesitation pause ('paused') (1.5s to 3.5s)
 * 6. Send message & save conversation history
 */
async function processSlowHumanReply(pending) {
  const { senderJid, cleanPhone, messages, lastMsgKey } = pending;
  if (!sock || !isConnectedState) return;

  try {
    const combinedIncomingText = messages.join('\n');
    console.log(`\n🤖 [Slow Human AI Responding to ${cleanPhone}]: "${combinedIncomingText.replace(/\n/g, ' ')}"`);

    // 1. Mark message as read (blue ticks)
    try {
      if (lastMsgKey) {
        await sock.readMessages([lastMsgKey]);
      }
    } catch (e) {}

    // 2. Slow human reading & thinking delay (12s to 24s)
    const readDelayMs = 12000 + Math.floor(Math.random() * 12000);
    console.log(`👀 [Human Reading] ${cleanPhone} chat opened. Reading for ${(readDelayMs / 1000).toFixed(0)}s...`);
    await sleep(readDelayMs);

    // Retrieve previous conversation history
    const history = conversationHistories.get(cleanPhone) || [];

    // 3. Generate AI response
    let replyText = await ai.handleIncomingMessage(cleanPhone, combinedIncomingText, history);
    if (!replyText || !replyText.trim()) return;
    replyText = replyText.trim();

    // 4. Realistic human typing presence ('composing') based on reply length (7s - 18s)
    const typingDurationMs = Math.min(
      18000,
      Math.max(7000, replyText.length * 48 + Math.floor(Math.random() * 3000))
    );

    console.log(`✍️ [Human Typing] Sending 'composing' presence to ${cleanPhone} for ${(typingDurationMs / 1000).toFixed(1)}s...`);
    try {
      await sock.sendPresenceUpdate('composing', senderJid);
    } catch (e) {}

    await sleep(typingDurationMs);

    // 5. Short hesitation pause before hitting send ('paused' presence)
    try {
      await sock.sendPresenceUpdate('paused', senderJid);
    } catch (e) {}
    const pauseBeforeSendMs = 1500 + Math.floor(Math.random() * 2000);
    await sleep(pauseBeforeSendMs);

    // 6. Send the message
    await sock.sendMessage(senderJid, { text: replyText });
    console.log(`✅ [Slow Human AI Reply Sent to ${cleanPhone}]:\n"${replyText}"\n`);

    // 7. Update in-memory conversation history (keep last 8 turns)
    history.push({ role: 'user', content: combinedIncomingText });
    history.push({ role: 'assistant', content: replyText });
    if (history.length > 8) history.splice(0, history.length - 8);
    conversationHistories.set(cleanPhone, history);

  } catch (err) {
    console.error(`❌ [Error in processSlowHumanReply for ${cleanPhone}]:`, err.message);
  }
}

/**
 * Fast WhatsApp existence validation via Baileys USync protocol
 * Guarantees we NEVER count or message landlines or unregistered numbers
 */
async function checkNumberOnWhatsApp(phoneOrJid) {
  if (!sock || !isConnectedState) return { exists: false, jid: null };

  try {
    const cleanDigits = String(phoneOrJid).replace(/\D/g, '');
    const results = await sock.onWhatsApp(cleanDigits);
    if (results && Array.isArray(results) && results.length > 0 && results[0]?.exists) {
      return { exists: true, jid: results[0].jid || `${cleanDigits}@s.whatsapp.net` };
    }
    return { exists: false, jid: null };
  } catch (err) {
    console.warn(`⚠️ [WhatsApp Verify Warning for ${phoneOrJid}]:`, err.message);
    return { exists: false, jid: null };
  }
}

/**
 * Send Text Message to a lead JID
 */
async function sendTextMessage(jid, text) {
  if (!sock || !isConnectedState) {
    console.warn('Cannot send message: WhatsApp socket is not connected');
    return false;
  }

  try {
    // 1. Human-like read/idle pause
    await sock.sendPresenceUpdate('available');
    await new Promise(r => setTimeout(r, 1200 + Math.random() * 1000));

    // 2. Realistic human typing presence (4.5 to 8.5s) to look 100% human to WhatsApp telemetry
    await sock.sendPresenceUpdate('composing', jid);
    const typingDelay = Math.floor(4500 + Math.random() * 4000);
    await new Promise(r => setTimeout(r, typingDelay));
    
    // 3. Send message
    await sock.sendMessage(jid, { text: text });
    await sock.sendPresenceUpdate('paused', jid);
    return true;
  } catch (err) {
    console.error(`Error sending message to ${jid}:`, err.message);
    return false;
  }
}

function getQrCodeDataUrl() {
  return currentQrCodeDataUrl;
}

function isConnected() {
  return isConnectedState;
}

function getConnectedNumber() {
  return userPhone;
}

module.exports = {
  initWhatsApp,
  sendTextMessage,
  checkNumberOnWhatsApp,
  hasExistingChat,
  getQrCodeDataUrl,
  isConnected,
  getConnectedNumber
};
