/**
 * 24-Hour Master Anti-Ban Queue Dispatcher
 * Rule: 1 msg every ~110s (Batch of 15) -> 115-minute (~2 hour) cool-down break
 * Exactly 10 cycles across 24 hours = 150 verified real leads delivered with 0% spike risk
 */

const ai = require('./ai');
const scraper = require('./scraper');

const BATCH_SIZE = parseInt(process.env.BATCH_SIZE || '15', 10);
const DELAY_BETWEEN_MSGS_MS = parseInt(process.env.DELAY_BETWEEN_MSGS_MS || '110000', 10); // ~110 seconds (1.8 mins)
const BATCH_BREAK_MS = parseInt(process.env.BATCH_BREAK_MS || '6900000', 10); // 115 minutes (~2 hour cool-down)
const DAILY_MAX_LEADS = parseInt(process.env.DAILY_MAX_LEADS || '150', 10); // Exactly 150 real leads per 24 hours

let isRunning = false;
let isPaused = false;
let isProactiveScraping = false;
let currentBatchCount = 0;
let totalSentSession = 0;
let dailySentCount = 0;
let currentDay = new Date().toDateString();
let nextActionTime = null;
let currentStatus = 'Idle';

function checkAndResetDailyCounter() {
  const today = new Date().toDateString();
  if (today !== currentDay) {
    currentDay = today;
    dailySentCount = 0;
    console.log(`🌅 [Anti-Ban Engine] New calendar day. Daily outreach counter reset to 0/${DAILY_MAX_LEADS}`);
  }
}

/**
 * Format timestamp into exact Indian Standard Time (IST, 12-hour format)
 */
function formatIndiaTime(timestamp) {
  if (!timestamp) return null;
  try {
    return new Date(timestamp).toLocaleTimeString('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }) + ' IST';
  } catch (e) {
    return new Date(timestamp).toLocaleTimeString('en-IN') + ' IST';
  }
}

function getQueueState() {
  const db = scraper.loadDatabase();
  const queuedCount = db.leads.filter(l => l.status === 'queued').length;
  const sentCount = db.leads.filter(l => l.status === 'sent').length;
  checkAndResetDailyCounter();

  return {
    isRunning,
    isPaused,
    currentStatus,
    currentBatchCount,
    batchSize: BATCH_SIZE,
    dailySentCount,
    dailyMaxLeads: DAILY_MAX_LEADS,
    totalSentSession,
    totalSentDb: sentCount,
    queuedRemaining: queuedCount,
    nextActionTime: formatIndiaTime(nextActionTime)
  };
}

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Start the worker loop
 */
async function startQueueWorker(whatsappClient) {
  if (isRunning) return;
  isRunning = true;
  console.log(`🚀 [Queue Worker] 24-Hour Master Engine Active! Formula: 1 msg/~110s (Batch of 15 verified leads) -> 115-min cool-down break. Exactly 10 cycles = 150 real leads spread across 24 hours (Times in IST).`);

  while (isRunning) {
    if (isPaused) {
      currentStatus = 'Paused by User';
      await sleep(5000);
      continue;
    }

    // Check if daily anti-ban ceiling has been reached
    checkAndResetDailyCounter();
    if (dailySentCount >= DAILY_MAX_LEADS) {
      currentStatus = `Daily Anti-Ban Safety Cap Reached (${dailySentCount}/${DAILY_MAX_LEADS}). Resting until tomorrow...`;
      await sleep(60000);
      continue;
    }

    // Check if WhatsApp is connected
    if (!whatsappClient || !whatsappClient.isConnected()) {
      currentStatus = 'Waiting for WhatsApp Web QR connection...';
      await sleep(10000);
      continue;
    }

    // Proactively top up queue in the background if under 35 leads remaining
    const remainingInQueue = scraper.getQueuedLeads(50).length;
    if (remainingInQueue < 35 && !isProactiveScraping) {
      isProactiveScraping = true;
      console.log(`⚡ [Continuous Scraper] Queue has ${remainingInQueue} leads (<35). Turbo harvesting fresh US leads in background...`);
      scraper.triggerFreeWebScraper({ targetCount: 40 })
        .catch(e => console.error('Continuous harvest notice:', e.message))
        .finally(() => { isProactiveScraping = false; });
    }

    // Get next lead
    let batch = scraper.getQueuedLeads(1);
    if (batch.length === 0) {
      currentStatus = 'Queue Empty: Harvesting fresh business leads (100% Free)...';
      console.log('🔍 [Auto-Scraper] Queue is empty! Automatically triggering Turbo Scraper (Zero API cost)...');
      try {
        await scraper.triggerFreeWebScraper({ targetCount: 40 });
      } catch (err) {
        console.error('Free Auto-scraper error:', err.message);
        if (process.env.APIFY_API_TOKEN) {
          console.log('⚠️ [Auto-Scraper] Trying Apify fallback...');
          try { await scraper.triggerApifyLeadDiscovery(); } catch (e) {}
        }
      }
      batch = scraper.getQueuedLeads(1);
      if (batch.length === 0) {
        console.log('⏳ [Auto-Scraper] Waiting 15s before next auto-scrape cycle...');
        await sleep(15000);
        continue;
      }
    }

    const lead = batch[0];

    // Absolute duplicate protection: Never message anyone who was previously contacted (or in older bot chat)
    if (scraper.isPhoneAlreadySent(lead.phone) || whatsappClient.hasExistingChat(lead.phone) || lead.status === 'sent') {
      console.log(`⏩ [Duplicate / Older Bot Shield] ${lead.phone} was already contacted. Skipping!`);
      scraper.updateLeadStatus(lead.phone, 'sent');
      continue;
    }

    // 2. CHECK IF NUMBER IS REGISTERED ON WHATSAPP!
    currentStatus = `Checking WhatsApp status for ${lead.phone}...`;
    const waCheck = await whatsappClient.checkNumberOnWhatsApp(lead.phone);
    if (!waCheck.exists) {
      console.log(`❌ [Not on WhatsApp] ${lead.phone} is a landline or not registered on WhatsApp. Skipping without counting!`);
      scraper.updateLeadStatus(lead.phone, 'not_on_whatsapp');
      await sleep(200);
      continue;
    }

    // Update JID to verified official WhatsApp JID
    lead.jid = waCheck.jid;

    // Check if batch limit (15 msgs) reached -> Take 115 min (~2 hr) break
    if (currentBatchCount >= BATCH_SIZE) {
      currentStatus = `Batch of ${BATCH_SIZE} complete. Taking 115-min cool-down break for WhatsApp safety...`;
      nextActionTime = Date.now() + BATCH_BREAK_MS;
      console.log(`\n☕ [Queue Worker] Exactly ${BATCH_SIZE} verified WhatsApp messages delivered! Taking 115-minute (~2 hour) cool-down break until ${formatIndiaTime(nextActionTime)}...\n`);
      
      await sleep(BATCH_BREAK_MS);
      
      currentBatchCount = 0;
      console.log(`⚡ [Queue Worker] Cool-down break finished! Resuming next batch...`);
    }

    // Prepare personalized message via Groq AI
    currentStatus = `Generating AI outreach for ${lead.phone} (${lead.country || 'USA'})...`;
    console.log(`🤖 [Groq AI] Generating personalized outreach for ${lead.phone} (${lead.country || 'USA'})...`);
    const outreachText = await ai.generateOutreachMessage(lead);

    // Send via WhatsApp
    currentStatus = `Sending message to ${lead.phone}...`;
    let sendSucceeded = false;
    try {
      const sent = await whatsappClient.sendTextMessage(lead.jid, outreachText);
      if (sent) {
        scraper.updateLeadStatus(lead.phone, 'sent');
        currentBatchCount++;
        totalSentSession++;
        dailySentCount++;
        sendSucceeded = true;
        console.log(`✅ [Real WhatsApp Sent ${currentBatchCount}/${BATCH_SIZE}] To ${lead.phone}. Session: ${totalSentSession} | Today: ${dailySentCount}/${DAILY_MAX_LEADS}`);
      } else {
        scraper.updateLeadStatus(lead.phone, 'failed', 'Socket send failure');
      }
    } catch (sendErr) {
      console.error(`❌ [Send Error] Failed to send to ${lead.phone}:`, sendErr.message);
      scraper.updateLeadStatus(lead.phone, 'failed', sendErr.message);
    }

    // Only apply human pacing delay if a message was actually delivered
    if (sendSucceeded) {
      if (currentBatchCount >= BATCH_SIZE) {
        currentStatus = `Batch of ${BATCH_SIZE} complete. Taking 115-min cool-down break...`;
        nextActionTime = Date.now() + BATCH_BREAK_MS;
        console.log(`\n☕ [Queue Worker] Batch limit hit (${BATCH_SIZE} delivered). Taking 115-min break until ${formatIndiaTime(nextActionTime)}...\n`);
        await sleep(BATCH_BREAK_MS);
        currentBatchCount = 0;
      } else {
        // Dynamic Human Jitter: 95s to 125s (averaging ~110 seconds = 1.8 mins per message)
        const humanJitterDelay = Math.floor(95000 + Math.random() * 30000);
        currentStatus = `Waiting ${Math.round(humanJitterDelay / 1000)}s before next lead (~110s pacing)...`;
        nextActionTime = Date.now() + humanJitterDelay;
        console.log(`⏳ [Pacing ~110s] Next message scheduled at ${formatIndiaTime(nextActionTime)} (${Math.round(humanJitterDelay / 1000)}s delay)...`);
        await sleep(humanJitterDelay);
      }
    } else {
      await sleep(1000);
    }
  }
}

function pauseQueue() {
  isPaused = true;
  console.log('⏸️ [Queue Worker] Paused');
}

function resumeQueue() {
  isPaused = false;
  console.log('▶️ [Queue Worker] Resumed');
}

module.exports = {
  startQueueWorker,
  pauseQueue,
  resumeQueue,
  getQueueState
};
